package com.customer.UserDtls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserDtls {

    public static void main(String[] args) {
        SpringApplication.run(UserDtls.class, args);
    }

}
